//
//  QQUIMessageCell.h
//  QQUI
//
//  Created by 向元新 on 15/11/11.
//  Copyright © 2015年 向元新. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "messagesModel.h"
#import "messageFrames.h"


@interface QQUIMessageCell : UITableViewCell


@property(nonatomic, copy)messageFrames *frames;

@end
