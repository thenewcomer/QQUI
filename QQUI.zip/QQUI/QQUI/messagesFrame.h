//
//  messagesFrame.h
//  QQUI
//
//  Created by 向元新 on 15/11/9.
//  Copyright © 2015年 向元新. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CoreGraphics/CoreGraphics.h>
//#import "messagesModel.h"


//#define messageFont [UIFont systemFontOfSize:14]
//
@interface messagesFrame : NSObject
////模型
//@property (nonatomic, copy)messagesModel *model;
//
////时间戳frame
//@property (nonatomic, assign, readonly)CGRect timeFrame;
//
////文本的frame
//@property (nonatomic, assign, readonly)CGRect messageFrame;
//
////头像的frame
//@property (nonatomic, assign, readonly)CGRect iconFrame;
//
////行高
//@property (nonatomic, assign, readonly)CGFloat rowHeight;
@end
